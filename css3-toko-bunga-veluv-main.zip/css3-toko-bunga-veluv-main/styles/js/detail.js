$('.owl-carousel').owlCarousel({
    loop:false,
    margin:0,
    nav:false,
    dots: true,
    responsive:{
        0:{
            items:1
        }
    }
});