let widthScan = $('.nav-scan').width();
$('.nav-scan').css({'height': widthScan+'px'});